#!/usr/bin/perl -w

# gen.pl
use strict;
my $LINES=0;
my $COLS=0;
use POSIX qw(ceil);
use Time::HiRes qw(usleep);
use Tk;
use Tk::PNG;
use Tk::ROText;

my $timeout = .1;
my $breed_speed = 2; # breeding occurs every $breed_speed loops, so 1 is max.
my $logfile = "gen.log";
my $stdout_fh;
my $gen = 0;
my $next_id = 0;
my $stop_flag = 0;
my $spin = 0;
my $debug = 0;
my $refresh = 0;
my $stop_after_gen = 0;
my $debug_after_gen = 0;
# key is item type, val is listref to items
my %tree;
# key is item id, val is listref to resonances
my %item_res;
# key is item id, val is listref to items
my %prev_joining_list;
# key is item id, val is item ref
my %active_item;
# key is item id; val is list ref to list of rect refs
my %item_exclude;
my $GY=70;
my $GX=70;
# tk variables
my $main_win;
my $td_canvas;
# images
my $red_img;
my $green_img;
my $blue_img;
# keyed by color name
my %small_img;
my %td_img;
my %roof_img;
my %roof_corner_img;
my $id_to_inspect = 0;

# types of objects
my $CELL = 0x01;
my $WALL = 0x02;
my $ROOF = 0x04;
my $PEDIMENT = 0x08;
my $RES = 0x10;
my $ROOM = 0x20;
my $BUILDING = 0x40;
my $COLUMN = 0x80;
my $MAP_WALL = 0x100;
my $RESKEY_THING = 0x200;

# type group masks
my $WALL_GROUP = $WALL | $ROOF | $PEDIMENT;
my $MAP_GROUP = $COLUMN | $MAP_WALL;
my $RESKEY_GROUP = $RESKEY_THING;

# states of objects
my $SEEK = 0x01;
my $BUILD = 0x02;
my $COMPLETING = 0x04;
my $WAITING = 0x08;
my $DEAD = 0x10;
my $FINISHED = 0x20;
my $JOIN = 0x40;

# state group masks
my $SEEKING_GROUP = $SEEK | $JOIN;

# creation flags
my $FL_ACTIVE=0x01;
my $FL_RESONATE=0x02;

# cell images based on state
my %state_color = (
	$SEEK => "red", # not used
	$BUILD => "orange",
	$COMPLETING => "yellow",
	$WAITING => "green",
	);

# cell images based on age (when in seek state)
my %seek_color = (
	0 => "red",
	1 => "orange",
	2 => "yellow",
	3 => "green",
	4 => "blue",
	5 => "violet",
	);

# object lifespan
my %lifespan = (
	$CELL => 100,
	$WALL => 50,
	$ROOM => 3000, # this is modified by room size
	);

sub
done { 
	print "@_\n";
	exit;
}

sub
numeric {
	$a <=> $b;
}
sub
rev_numeric {
	$b <=> $a;
}

sub
min(@) { 
	my $min = undef;
	foreach (@_) {
		$min = $_ if !defined($min) || $_ < $min;
	}
	return $min;
}

sub
max(@) { 
	my $max = undef;
	foreach (@_) {
		$max = $_ if !defined($max) || $_ > $max;
	}
	return $max;
}

sub 
pyramid_res_map {
	my $thing = shift;

	# check if we've calculated the map for this before
	if (defined ($$thing{cache_layer}) && $$thing{cache_layer} == $$thing{layer}) {
		return $$thing{cached_map};
	}

	# this attribute is derived from the nature of this function; other shapes
	# will find their heights differently.
	$$thing{final_height} = int ((min($$thing{x_dim},$$thing{y_dim})+1)/2)
		unless defined($$thing{final_height});

	my $curr_x = $$thing{x_dim} - 2 * $$thing{layer};
	my $curr_y = $$thing{y_dim} - 2 * $$thing{layer};

	if ($curr_x < 1 || $curr_y < 1) {
		print "Current layer gives <1 dim(s) for $$thing{id}\n";
		return;
	}

	# this routine will return a reference to this list
	my @resmap;

	# single-width maps are a special case
	if ($curr_x == 1 || $curr_y == 1) {
		if ($curr_x == 1) {
			if ($curr_y == 1) {
				push @resmap, [ 0, 0, { nature => $ROOF, tile_shape => 4 } ];
			}
			else {
				# vertical roof ridge
			}
		}
		else {
			# horizontal roof ridge

			# ends
			push @resmap, [ $min_x, $min_y, { angle => 0, nature => $ROOF, tile_shape => 5 } ];
			push @resmap, [ $min_x + $curr_x - 1, $min_y, { angle => 1, nature => $ROOF, tile_shape => 5 } ];
		}
	}
	else {
		my $min_x = - int(($curr_x-1)/2);
		my $min_y = - int(($curr_y-1)/2);

		# corners
		push @resmap, [ $min_x, $min_y, { angle => 0, nature => $ROOF, tile_shape => 3 } ];
		push @resmap, [ $min_x + $curr_x - 1, $min_y, { angle => 1, nature => $ROOF, tile_shape => 3 } ];
		push @resmap, [ $min_x + $curr_x - 1, $min_y + $curr_y - 1, { angle => 2, nature => $ROOF, tile_shape => 3 } ];
		push @resmap, [ $min_x, $min_y + $curr_y - 1, { angle => 3, nature => $ROOF, tile_shape => 3 } ];

		if ($curr_x > 2) {
			# horiz sides
			for (my $i = 0; $i < $curr_x - 2; $i++) {
				push @resmap, [ $min_x + 1 + $i, $min_y,
					{ angle => 0, nature => $ROOF, tile_shape => 1 } ];
				push @resmap, [ $min_x + 1 + $i, $min_y + $curr_y - 1,
					{ angle => 2, nature => $ROOF, tile_shape => 1 } ];
			}
		}

		if ($curr_y > 2) {
			# vert sides
			for (my $i = 0; $i < $curr_y - 2; $i++) {
				push @resmap, [ $min_x, $min_y + 1 + $i,
					{ angle => 3, nature => $ROOF, tile_shape => 1 } ];
				push @resmap, [ $min_x + $curr_x - 1, $min_y + 1 + $i,
					{ angle => 1, nature => $ROOF, tile_shape => 1 } ];
			}
		}

	}
	if ($debug) {
		foreach my $res (@resmap) {
			my ($x, $y, $attribs) = @$res;
			print "$x,$y a $$attribs{angle}, t $$attribs{tile_shape}\n";
		}
	}

	# cache this map
	$$thing{cached_map} = \@resmap;
	$$thing{cache_layer} = $$thing{layer};

	return \@resmap;

}

sub
make_plan()
{
	my $nbr_changed_corners = ceil(rand(4));
	# print "hack; ncc = $nbr_changed_corners\n";

	my @new_corner_move = ( [1,-1], [1,1], [-1,1], [-1,-1],);

	my @corner_move = ( [1,0], [0,1], [-1,0], [0,-1],);
	my $x_dir = ${$corner_move[3]}[0];
	my $y_dir = ${$corner_move[3]}[1];

	# note that axes are screen, not cartesian, ie origin is top left.
	# initial points, a simple square
	my @corner = ( { x => 0, y => 0 }, { x => 1, y => 0 }, { x => 1, y => 1 }, { x => 0, y => 1 }, );
	# list of all points
	my @new_corners;
	my $x = ${$corner[3]}{x};
	my $y = ${$corner[3]}{y};

	foreach (0..3) {
		# print "Current location = $x,$y, dir = $x_dir,$y_dir\n";

		# place this corner, ie move it into the line of direction 
		# at least 1 along that line from the current corner
		if ($x_dir) {
			if ($_ == 3 && $nbr_changed_corners > 0) {
				# boy, this sucks; for the last corner, if it is followed by
				# an extra corner (thus making a cross), we have to manually hack
				# the new pos so it lines up with the first corner...
				${$corner[$_]}{x}++;
			}
			${$corner[$_]}{x} = $x_dir > 0 ? max ($x+1, ${$corner[$_]}{x}) : min ($x-1, ${$corner[$_]}{x}); 
			${$corner[$_]}{y} = $y;
		}
		else {
			${$corner[$_]}{x} = $x;
			${$corner[$_]}{y} = $y_dir > 0 ? max ($y, ${$corner[$_]}{y}) : min ($y-1, ${$corner[$_]}{y}); 
		}
		# current position to new corner
		$x = ${$corner[$_]}{x};
		$y = ${$corner[$_]}{y};
		# print "Place corner $_ at $x,$y\n";
		push @new_corners, [ $x,$y ];
		# switch direction for corner
		$x_dir = ${$corner_move[$_]}[0];
		$y_dir = ${$corner_move[$_]}[1];
		# maybe draw corner
		if ($nbr_changed_corners-- > 0) {
			my $dx = ${$new_corner_move[$_]}[0];
			my $dy = ${$new_corner_move[$_]}[1];
			# move the current position
			# draw the lines; we draw the line across the current direction first
			if ($x_dir) {
				$x += $x_dir;
				push @new_corners, [ $x,$y ];
				$y += $dy;
				push @new_corners, [ $x,$y ];
			}
			else {
				$y += $y_dir;
				push @new_corners, [ $x,$y ];
				$x += $dx;
				push @new_corners, [ $x,$y ];
			}
		}
	}

	# convert the list of points to a list of positive unit (ie based on 1x1) offsets
	# We must do this in several stages (offset, protrusions, minimums, adjusted offsets)
	# since finding protrusions is much easier using offsets,

	my @offset;

	# simple offsets
	my $prev_x = 0;
	my $prev_y = 0;
	foreach my $point (@new_corners) {
		my ($x,$y) = @$point;
		push @offset, [ $x - $prev_x, $y - $prev_y ];
		$prev_x = $x;
		$prev_y = $y;
	}

	# replace the 0,0 offset from the start of the list with a pair
	# representing the offset from the final point back to the origin
	# so we can look "around" the end of the list to the neighbouring offset.
	shift @offset;
	unshift @offset, [ $prev_x ? -$prev_x : 0, $prev_y ? -$prev_y : 0 ];

	# find protrusions ; list is indexes of the middle offset
	my @protrusions;
	for (my $i=0;$i <= $#offset; $i++) {
		my ($x,$y) = @{$offset[$i]};
		($prev_x, $prev_y) = @{$offset[$i > 0 ? $i-1 : $#offset ]};
		my ($next_x, $next_y) = @{$offset[ $i < $#offset ? $i+1 : 0]};
		if ((abs($x) == 1 && $prev_x == 0 && $next_x == 0 && ($prev_y * $next_y < 0))
			|| (abs($y) == 1 && $prev_y == 0 && $next_y == 0 && ($prev_x * $next_x < 0)))
		{
			push @protrusions, $i;
		}
	}
	# add a dummy meaning "no protrusion"
	push @protrusions, -1;

	# pick one index at random
	# looks bad, but we're just getting and assigining a random index and then
	# testing the element at that index.
	if ((my $pro_index = $protrusions[ int(rand()*($#protrusions + 1))]) > -1) {

		# stretch the offsets (ie increase their magnitude) to either side
		# of the protruding offset
		my $next_index = $pro_index < $#offset ? $pro_index + 1 : 0;
		my $prev_index = $pro_index > 0 ? $pro_index - 1 : $#offset;
		if (${$offset[$pro_index]}[0]) {
			${$offset[$next_index]}[1] += ${$offset[$next_index]}[1] > 0 ? 1 : -1;
			${$offset[$prev_index]}[1] += ${$offset[$prev_index]}[1] > 0 ? 1 : -1;
		}
		else {
			${$offset[$next_index]}[0] += ${$offset[$next_index]}[0] > 0 ? 1 : -1; 
			${$offset[$prev_index]}[0] += ${$offset[$prev_index]}[0] > 0 ? 1 : -1;
		}
	}

	# restore the 0,0 offset since we want this when actually using the offsets.
	shift @offset;
	unshift @offset, [ 0,0 ];

	my $min_x = 0;
	my $min_y = 0;
	my $max_x = 0;
	my $max_y = 0;
	my $real_x = 0;
	my $real_y = 0;
	# find the minimums so the real position never goes "below" the origin; this means we can specify a 
	# location point at the top left of the area.
	foreach my $offset_info (@offset) {
		my ($x,$y) = @$offset_info;
		$real_x += $x;
		$real_y += $y;
		$min_x = $real_x if $real_x < $min_x;
		$min_y = $real_y if $real_y < $min_y;
		$max_x = $real_x if $real_x > $max_x;
		$max_y = $real_y if $real_y > $max_y;
	}
	shift @offset;
	# avoid unsightly -0
	unshift @offset, [ $min_x ? -$min_x : 0, $min_y ? -$min_y : 0 ];

	return \@offset, $max_x - $min_x, $max_y - $min_y;

}

sub
fit_plan($$$@)
{
	my ($point, $width, $height, $min_grid_size) = splice (@_, 0, 4);
	my @rect = @_;

	if ($#rect != 3) {
		print "fit_plan: rect (@rect) does not have 4 entries\n";
		return;
	}

	my $rect_width = $rect[2] - $rect[0];
	my $rect_height = $rect[3] - $rect[1];

	# we need to swap the point x&y coords if the plan and the rect 
	# run in different directions, eg long sides aren't both x or y.
	# Do nothing if either area is a square.
	if ($width > $height && $rect_width < $rect_height) {
		# swap points
		foreach (@$point) {
			my ($x,$y) = @$_;
			$$_[0] = $y;
			$$_[1] = $x;
		}
		# swap plan dimensions
		my $tmp = $width;
		$width = $height;
		$height = $tmp;
	}

	# calculate the dimension of the unit point coord in the rect
	my $PAD = $min_grid_size > 4 ? 5 : 3;
	my $x_grid = int(($rect_width - $PAD*2) / $width);
	my $y_grid = int(($rect_height - $PAD*2) / $height);

	# make sure we have a minimum grid size ; we've already swapped
	# the point coords but we'll be discarding this plan anyway.
	return 0 if min($x_grid,$y_grid) < $min_grid_size;

	# make sure the ratio between x & y grids is no more than 2
	$x_grid = min($x_grid, $y_grid*3) if $x_grid > $y_grid;
	$y_grid = min($y_grid, $x_grid*3) if $x_grid < $y_grid;

	# convert the point offsets to real grid coords
	my $prev_x = $rect[0] + $PAD;
	my $prev_y = $rect[1] + $PAD;
	foreach (@$point) {
		my ($x,$y) = @$_;
		$prev_x = $$_[0] = $prev_x + $x * $x_grid;
		$prev_y = $$_[1] = $prev_y + $y * $y_grid;
	}

	return 1;

}

sub
tracker {
	my ($canvas, $x, $y) = @_;
	$x = $canvas->canvasx($x);
	$y = $canvas->canvasx($y);

	my $image_x_offset = 6;
	my $image_y_offset = 3;
	my $image_z_offset = 5;

	my $origin_x = 10;
	my $origin_y = 10;

	# move the origin according to the spin
	if ($spin == 0) {
		$origin_y += $GX * $image_y_offset;
	}
	elsif ($spin == 1) {
		$origin_x += $GY * $image_x_offset;
	}
	elsif ($spin == 2) {
		$origin_x += ($GX+$GY) * $image_x_offset;
		$origin_y += $GY * $image_y_offset;
	}
	elsif ($spin == 3) {
		$origin_x += $GX * $image_x_offset;
		$origin_y += ($GX+$GY) * $image_y_offset;
	}

	# move the y offset down to allow for building height
	$origin_y += 15 * $image_z_offset;

	# elements in spin matrix are:
	# x-coord x factor, x-coord y factor, y-coord x factor, y-coord y factor
	my $spin_matrix = (
		[ 1,1,-1,1 ],
		[ 1,-1,1,1 ],
		[ -1,-1,1,-1 ],
		[ -1,1,-1,-1 ]
		)[$spin];

	# hack
	$y -= 2;

	my $x_grid = int (( $$spin_matrix[3] * ($x - $origin_x) + 2 * $$spin_matrix[1] * ($origin_y - $y ) ) /
		(6 * ($$spin_matrix[0] * $$spin_matrix[3] - $$spin_matrix[1] * $$spin_matrix[2])));
	my $y_grid = int(( 2 * $$spin_matrix[0] * ($y - $origin_y) + $$spin_matrix[2] * ($origin_x - $x ) ) /
		(6 * ($$spin_matrix[0] * $$spin_matrix[3] - $$spin_matrix[1] * $$spin_matrix[2])));

	# find the cell at this point
	my $found_cell = undef;
	foreach my $cell (@{$tree{$CELL}}) {
		print " ($$cell{x},$$cell{y})" if $debug;
		$found_cell = $cell and last if $$cell{x} == $x_grid && $$cell{y} == $y_grid;
	}
	print "\n" if $debug;

	if ($found_cell) {
		if ($$found_cell{object}) {
			inspect(${$$found_cell{object}}{id});
		}
		else {
			print "Cell at $x_grid, $y_grid has no object\n" if $debug;
		}
	}
	else {
		print "Nothing at $x_grid, $y_grid\n" if $debug;
	}

=for comment
	print "x:   ";
	foreach $x (16..40) {
		print "  $x  ";
	}
	print "\n";
	foreach $y (292 .. 310) {
		print "$y: ";
		foreach $x (16..40) {

			my $x_grid = int (( $$spin_matrix[3] * ($x - $origin_x) + 2 * $$spin_matrix[1] * ($origin_y - $y ) ) /
				(6 * ($$spin_matrix[0] * $$spin_matrix[3] - $$spin_matrix[1] * $$spin_matrix[2])));
			my $y_grid = int(( 2 * $$spin_matrix[0] * ($y - $origin_y) + $$spin_matrix[2] * ($origin_x - $x ) ) /
				(6 * ($$spin_matrix[0] * $$spin_matrix[3] - $$spin_matrix[1] * $$spin_matrix[2])));

			#print "Tracker: x = $x, y = $y, x_grid = $x_grid, y_grid = $y_grid\n";
			# print " (",abs($x_grid),",",abs($y_grid),")";
			printf " %+1d,%+1d", $x_grid, $y_grid;
		}
		print "\n";
	}
=cut

}

sub 
render_tk_3d(;$) 
{

	my $full_refresh = shift;

	my $image_x_offset = 6;
	my $image_y_offset = 3;
	my $image_z_offset = 5;

	my $origin_x = 10;
	my $origin_y = 10;

	$full_refresh |= $gen % 10 == 0;

	# clear canvas
	$td_canvas->delete("all") if $full_refresh;

	my $seek_color_size = int($lifespan{$CELL} / 6) + 1;

	# create a hash of hashes, keyed by x & y coords. Use a hash to
	# make scanning the sparse result quicker.
	my $z_hash = {};
	my $y_hash;
	my $x_hash;

	# add cells to hash
	foreach my $cell (@{$tree{$CELL}}) {
		my $color;
		if ($$cell{state} & $SEEKING_GROUP) {
			$color = int($$cell{life} / $seek_color_size);
			$color = $seek_color{$color};
		}
		else {
			next unless $full_refresh;
			if ($$cell{nature} == $ROOF) {
				if ($$cell{tile_shape} == 4) {
					# point
					$color = "blue_roof_point";
				}
				elsif ($$cell{tile_shape} == 3) {
					# corner
					$color = "blue_roof_" . qw(nw ne se sw)[($spin + $$cell{angle}) % 4];
				}
				elsif ($$cell{tile_shape} == 2) {
					# ridge
					$color = "blue_ridge_" . ($spin % 2 == $$cell{horiz} ? 'ns' : 'ew');
				}
				elsif ($$cell{tile_shape} == 1) {
					# normal tile
					$color = "blue_roof_" . qw(n e s w)[($spin + $$cell{angle}) % 4];
				}
				else {
					print "Roof $$cell{id} has unknown tile_shape\n";
				}
			}
			else {
				$color = $state_color{$$cell{state}};
			}
		}

		$$z_hash{$$cell{z}} = {} unless $$z_hash{$$cell{z}};
		$y_hash = $$z_hash{$$cell{z}};

		$$y_hash{$$cell{y}} = {} unless $$y_hash{$$cell{y}};
		$x_hash = $$y_hash{$$cell{y}};

		$$x_hash{$$cell{x}} = $color;
	}
	# add the origin
	${${$$z_hash{0}}{0}}{0} = 'blue';

	if (1) {
		# draw a grid
		my $x_across = ($GX+1) * 6;
		my $y_across = ($GY+1) * 6;
		my $x_down = ($GX+1) * 3;
		my $y_down = ($GY+1) * 3;
		my $grid_down = 7;
		my $origin_y = 10 + $GX * $image_y_offset + 15 * $image_z_offset;

		$td_canvas->createLine($origin_x, $origin_y + $grid_down, $origin_x + $x_across, $origin_y - $x_down + $grid_down);
		$td_canvas->createLine($origin_x, $origin_y + $grid_down, $origin_x + $y_across, $origin_y + $y_down + $grid_down);
		$td_canvas->createLine($origin_x + $x_across, $origin_y - $x_down + $grid_down, 
			$origin_x + $x_across + $y_across, $origin_y - $x_down + $y_down + $grid_down); 
		$td_canvas->createLine($origin_x + $y_across, $origin_y + $y_down + $grid_down,
			$origin_x + $y_across + $x_across, $origin_y + $y_down - $x_down + $grid_down);
	}

	# move the origin according to the spin
	if ($spin == 0) {
		$origin_y += $GX * $image_y_offset;
	}
	elsif ($spin == 1) {
		$origin_x += $GY * $image_x_offset;
	}
	elsif ($spin == 2) {
		$origin_x += ($GX+$GY) * $image_x_offset;
		$origin_y += $GY * $image_y_offset;
	}
	elsif ($spin == 3) {
		$origin_x += $GX * $image_x_offset;
		$origin_y += ($GX+$GY) * $image_y_offset;
	}
	# move the y offset down to allow for building height
	$origin_y += 15 * $image_z_offset;
	print "Spin = $spin, origin = $origin_x, $origin_y\n" if $debug;

	# move through the coordinates in an appropriate direction for the spin
	my (@x_list, @y_list);

	# elements in spin matrix are:
	# x-coord x factor, x-coord y factor, y-coord x factor, y-coord y factor
	my $spin_matrix = (
		[ 1,1,-1,1 ],
		[ 1,-1,1,1 ],
		[ -1,-1,1,-1 ],
		[ -1,1,-1,-1 ]
		)[$spin];

	# display the hashes
	foreach my $z (sort numeric keys %$z_hash) {
		$y_hash = $$z_hash{$z};
		@y_list = $spin < 2 ? sort numeric keys %$y_hash : sort rev_numeric keys %$y_hash;
		foreach my $y (@y_list) {
			$x_hash = $$y_hash{$y};
			@x_list = ($spin == 1 || $spin == 2) ? sort numeric keys %$x_hash : sort rev_numeric keys %$x_hash;
			foreach my $x (@x_list) {
				# print "x = $x, y = $y, color = $$x_hash{$x}\n";
				my $x_coord =
					$origin_x + $x * 6 * $$spin_matrix[0] + $y * 6 * $$spin_matrix[1];
				my $y_coord =
					$origin_y + $x * 3 * $$spin_matrix[2] + $y * 3 * $$spin_matrix[3] - $z * $image_z_offset;
				$td_canvas->createImage(
					$x_coord, $y_coord,
					-image => $td_img{$$x_hash{$x}},
					-anchor => 'nw');
			}
		}
	}

=for comment

	# corners
	$td_canvas->createImage( $origin_x, $origin_y, -image => $td_img{blue}, -anchor => 'nw');
	$td_canvas->createImage( $origin_x + $GX * 6, $origin_y - $GX * 3, -image => $td_img{blue}, -anchor => 'nw');
	$td_canvas->createImage( $origin_x + $GY * 6, $origin_y + $GY * 3, -image => $td_img{blue}, -anchor => 'nw');
	$td_canvas->createImage( $origin_x + $GX * 6 + $GY * 6, $origin_y - $GX * 3 + $GY * 3, -image => $td_img{blue}, -anchor => 'nw');

=cut

	$td_canvas->idletasks;

}

sub 
render_tk() 
{

	my $seek_color_size = int($lifespan{$CELL} / 6) + 1;
	my $canvas = $td_canvas;

	# clear canvas
	$canvas->delete("all");

	my $image_width = $small_img{red}->width;
	my $image_height = $small_img{red}->height;

	# add cells to map
	foreach my $cell (@{$tree{$CELL}}) {
		my $color;
		if ($$cell{state} & $SEEKING_GROUP) {
			$color = int($$cell{life} / $seek_color_size);
			$color = $seek_color{$color};
		}
		else {
			$color = $state_color{$$cell{state}};
		}
		$canvas->createImage(($$cell{y}+1)*$image_width,($GX-$$cell{x})*$image_height,-image => $small_img{$color});
	}

	# corners
	$canvas->createImage($image_width,$GX*$image_width,-image => $small_img{blue});
	# $canvas->createImage($GX*$image_width,$image_width,-image => $small_img{blue});
	# $canvas->createImage($image_width,$GY*$image_height,-image => $small_img{blue});
	# $canvas->createImage($GX*$image_width,$GY*$image_height,-image => $small_img{blue});

	$canvas->idletasks;

}

sub
get_distance($$) 
{
	my (@x, @y);

	foreach my $thing (@_) {
		if ($$thing{type} == $CELL) {
			push @x, $$thing{x};
			push @y, $$thing{y};
		}
		elsif ($$thing{type} == $WALL) {
			# measure from midpoint
			if ($$thing{horiz}) {
				push @x, $$thing{end_1} + $$thing{len} / 2;
				push @y, $$thing{line};
			}
			else {
				push @x, $$thing{line};
				push @y, $$thing{end_1} + $$thing{len} / 2;
			}
		}
		elsif ($$thing{type} == $RES) {
			push @x, $$thing{x};
			push @y, $$thing{y};
		}
		elsif ($$thing{type} == $ROOM) {
			my $rect = $$thing{rect};
			push @x, $$rect[0] + ($$rect[2] - $$rect[0])/2;
			push @y, $$rect[1] + ($$rect[3] - $$rect[1])/2;
		}
		else {
			print "Unknown type of thing ($$thing{type}) in get_distance\n";
			return undef;
		}
	}

	return abs(sqrt(($x[0] - $x[1])**2 + ($y[0] - $y[1])**2));
}

sub
rectangles_intersect($$) 
{
	my ($rect1, $rect2) = @_;

	# rectangles are described by x1,y1,x2,y2, top left to bottom right.
	# indexes
	my @rect1 = @$rect1;
	my @rect2 = @$rect2;

	# it's easier to check for non-intersection and negate it; for
	# that, at least one set of coords (x or y) must fail to intersect,
	# ie the range for rect1 lies wholly above or below the corres range
	# for rect2. Since we have ordered corners, relative positions are
	# fairly easy to do, eg if left1 > right2, we know 1 is above 2.

	return ! ($rect1[0] > $rect2[2] || $rect2[0] > $rect1[2] 
		|| $rect1[1] > $rect2[3] || $rect2[1] > $rect1[3]);

}

sub
update_resonances($) 
{

	my $thing = shift;
	my (@resonances, @valid_resonances);
	my %type_pri = (
		$CELL => 1,
		$WALL => 2,
		$MAP_WALL => 2,
		$ROOF => 3,
		$PEDIMENT => 4,
		$COLUMN => 5,
		$RESKEY_THING => 5,
		);

	print "update_resonances for $$thing{id}\n" if $debug;

	if ($$thing{type} == $CELL) {
		push @resonances, { x => $$thing{x}+1, y => $$thing{y} } if $$thing{x} < $GX-1;
		push @resonances, { x => $$thing{x}-1, y => $$thing{y} } if $$thing{x} > 0;
		push @resonances, { x => $$thing{x}, y => $$thing{y}+1 } if $$thing{y} < $GY-1;
		push @resonances, { x => $$thing{x}, y => $$thing{y}-1 } if $$thing{y} > 0;
	}
	elsif ($$thing{type} & ($WALL | $PEDIMENT)) {
		if ($$thing{horiz}) {
			my $end_1_limit = defined($$thing{final_end_1}) ? $$thing{final_end_1} : 0;
			my $end_2_limit = defined($$thing{final_end_2}) ? $$thing{final_end_2} : $GX-1;
			push @resonances,
				{ x => $$thing{end_1}-1, y => $$thing{line} } if $$thing{end_1} > $end_1_limit;
			push @resonances,
				{ x => $$thing{end_2}+1, y => $$thing{line} } if $$thing{end_2} < $end_2_limit
					&& (!defined($$thing{final_end_1})
						|| $$thing{final_end_1} != $$thing{final_end_2});
		}
		else {
			my $end_1_limit = defined($$thing{final_end_1}) ? $$thing{final_end_1} : 0;
			my $end_2_limit = defined($$thing{final_end_2}) ? $$thing{final_end_2} : $GY-1;
			push @resonances,
				{ x => $$thing{line}, y => $$thing{end_1}-1 } if $$thing{end_1} > $end_1_limit;
			push @resonances,
				{ x => $$thing{line}, y => $$thing{end_2}+1 } if $$thing{end_2} < $end_2_limit
					&& (!defined($$thing{final_end_1})
						|| $$thing{final_end_1} != $$thing{final_end_2});
		}
	}
	elsif ($$thing{type} == $ROOF) {
		my $line = $$thing{line};
		$line += $$thing{height} * (($$thing{angle} % 3) ? -1 : 1) if $$thing{tile_shape} == 1;
		if ($$thing{horiz}) {
			my $end_1_limit = defined($$thing{final_end_1}) ? $$thing{final_end_1} : 0;
			my $end_2_limit = defined($$thing{final_end_2}) ? $$thing{final_end_2} : $GX-1;
			push @resonances,
				{ x => $$thing{end_1}-1, y => $line } if $$thing{end_1} > $end_1_limit;
			push @resonances,
				{ x => $$thing{end_2}+1, y => $line } if $$thing{end_2} < $end_2_limit;
		}
		else {
			my $end_1_limit = defined($$thing{final_end_1}) ? $$thing{final_end_1} : 0;
			my $end_2_limit = defined($$thing{final_end_2}) ? $$thing{final_end_2} : $GY-1;
			push @resonances,
				{ x => $line, y => $$thing{end_1}-1 } if $$thing{end_1} > $end_1_limit;
			push @resonances,
				{ x => $line, y => $$thing{end_2}+1 } if $$thing{end_2} < $end_2_limit;
		}
	}
	elsif ($$thing{type} & $MAP_GROUP) {
		my $base_x = $$thing{x};
		my $base_y = $$thing{y};

=for comment
		my @heights = @{$$thing{heights}};
		foreach my $res (@{$$thing{resmap}}) {
			my $height = shift @heights;
			next if $height == $$thing{final_height};
			my ($x,$y) = @$res;
			push @resonances, { x => $base_x + $x, y => $base_y + $y };
		}
=cut

		my $resmap = $$thing{resmap};
		my $heights = $$thing{heights};
		for (my $i=0; $i <= $#$resmap; $i++) {
			next if $$heights[$i] == $$thing{final_height};
			my ($x,$y) = @{$$resmap[$i]};
			push @resonances, { x => $base_x + $x, y => $base_y + $y, res_index => $i };
		}
	}
	elsif ($$thing{type} & $RESKEY_GROUP) {
		my $base_x = $$thing{x};
		my $base_y = $$thing{y};
		my $layer = $$thing{layer};
		# my $reskey = $$thing{reskey};
		my $filled_res = $$thing{filled_res};
		my $resmap = $$thing{resfunc}
			?  &{$$thing{resfunc}}($thing)
			: ${$$thing{reskey}}{$layer};
		for (my $i=0; $i <= $#$resmap; $i++) {
			next if $$filled_res[$i];
			my ($x,$y,undef) = @{$$resmap[$i]};
			push @resonances, { x => $base_x + $x, y => $base_y + $y, res_index => $i };
		}
	}
	else {
		print "Unknown thing in update_resonances: $thing, $$thing{type}\n";
	}

	# add the standard elements for each res
	RES: foreach my $res (@resonances) {
		# check that the resonance is not in an exclusion
		ITEM: foreach my $id (keys %item_exclude) {
			# don't remove resonances because of the thing's own exclusions
			next if $id == $$thing{id};
			# if the thing is a wall or a roof, don't remove resonances because of
			# its room.
			if ( ($$thing{type} & ($WALL_GROUP | $MAP_WALL)) && $$thing{room}) {
				next if $id == ${$$thing{room}}{id};
			}
			# ditto for columns and buildings; we could just say "next if column",
			# since columns shouldn't be anywhere near valid exclusions...
			if ($$thing{type} == $COLUMN) {
				next if $id == ${$$thing{building}}{id};
			}

			foreach my $rect_ref (@{$item_exclude{$id}}) {

				print "exclusion rect = $$rect_ref[0], $$rect_ref[1], $$rect_ref[2], $$rect_ref[3]\n" if $debug; 

				# check the cell's location; cells in exclusions don't have any resonances,
				# in case another cell moves onto it and builds while the 1st cell is still
				# supposed to be excluded.
				if ($$thing{type} == $CELL && 
					rectangles_intersect($rect_ref, [ $$thing{x},$$thing{y},$$thing{x},$$thing{y} ])) {
					print "No resonances for cell inside exclusion; $$thing{id} at $$thing{x},$$thing{y}\n" if $debug;
					last RES;
				}

				print "Omitting res($$res{x},$$res{y}) for item $$thing{id} because of item $id\n"
					if rectangles_intersect($rect_ref, [ $$res{x},$$res{y},$$res{x},$$res{y} ]) && $debug;
				next RES if rectangles_intersect($rect_ref, [ $$res{x},$$res{y},$$res{x},$$res{y} ]);
			}

		}

		$$res{pri} = $type_pri{$$thing{type}};
		$$res{thing} = $thing;
		$$res{type} = $RES;

		push @valid_resonances, $res;
	}

	# store the resonances in the item resonance hash
	$item_res{$$thing{id}} = \@valid_resonances;

}

sub 
prune_resonances($$) 
{
	my ($thing,$new_rect) = @_;

	# we've just changed an exclusion; go thru all the resonances
	# and remove any that impinge on the newly excluded area.

	# this could be optimised by having a grid-based index of items with
	# resonances in that grid. Divide the world into 8x8 (say) squares
	# and for each square (ie a hash keyed by grid x_y) store a hash
	# of item keys where those items have resonances in the square.
	# Checking which grid squares are affected by a given prune area
	# would be fairly easy, and we'd then just have to check those items
	# for resonance pruning.

	print "pruning resonances for $$thing{id}\n" if $debug;

	ITEM: foreach my $id (keys %item_res) {
		# don't prune the thing's own resonances
		next if $$thing{id} == $id;

		# if the thing is a room, don't remove resonances from the things in the
		# room.
		if ($$thing{type} == $ROOM) {
			foreach my $wall (@{$$thing{walls}}) {
				next ITEM if $id == $$wall{id};
			}
			foreach my $roof (@{$$thing{roofs}}) {
				next ITEM if $id == $$roof{id};
			}
			foreach my $pediment (@{$$thing{pediments}}) {
				next ITEM if $id == $$pediment{id};
			}
		}

		# have to be careful here otherwise the splice changes the list 
		# as we're deleting from it. Delete from the list in reverse
		# order to stop reshuffling hurting us.
		for (my $i = $#{$item_res{$id}}; $i >= 0; $i--) {
			my $res = ${$item_res{$id}}[$i];
			if (rectangles_intersect($new_rect, [ $$res{x},$$res{y},$$res{x},$$res{y} ])) {
				print "pruning res $i for $id at $$res{x}, $$res{y} because of $$thing{id}\n" if $debug;
				splice @{$item_res{$id}},$i,1;
			}
		}
	}
}

sub
get_res_score($$) 
{
	my ($thing, $res) = @_;

	my $score = 0;

	# bail out if this resonance belongs to this thing
	return 0 if $thing == $$res{thing};

	if ($$thing{type} == $CELL) {
		# my $range = sqrt(($$thing{x} - $$res{x})**2 + ($$thing{y} - $$res{y})**2);
		my $range = get_distance($thing, $res);
		# add 1 to avoid div 0
		$score = $$res{pri}/($range+1);
	}
	else {
		print "Unknown thing in get_res_score: $thing, $$thing{type}\n";
	}

	return $score;
}

sub
create($$) 
{
	my ($thing, $flags) = @_;
	$$thing{id} = ++$next_id;

	# default current ends for walls
	if (defined($$thing{final_end_1}) && defined($$thing{final_end_2})) {
		my $final_end_1 = $$thing{final_end_1};
		my $final_end_2 = $$thing{final_end_2};
		$$thing{end_1} = $final_end_1 + int(($final_end_2-$final_end_1)/2) + 1 unless defined($$thing{end_1});
		$$thing{end_2} = $final_end_1 + int(($final_end_2-$final_end_1)/2) unless defined($$thing{end_2});
	}

	# default heights for a resmap
	if (defined($$thing{resmap})) {
		$$thing{heights} = [ map (0,(0..$#{$$thing{resmap}})) ]
			unless defined($$thing{heights});
		$$thing{cells} = [];
	}

	# default stuff for a reskey (different resonance maps keyed by current layer)
	# or a resfunc (different resonance maps generated by function )
	if ($$thing{type} & $RESKEY_GROUP) {
		if (my $reskey = $$thing{reskey}) {
			$$thing{final_height} = scalar keys %$reskey
				unless defined($$thing{final_height});
		}
		$$thing{cells} = [];
		$$thing{layer} = 0;
		$$thing{filled_res} = [];
	}

	# create the tree list for this type if we have to
	$tree{$$thing{type}} = [] unless $tree{$$thing{type}};

	# add this thing to its tree list
	push @{$tree{$$thing{type}}}, $thing;

	# actions conditional on flags
	$active_item{$$thing{id}} = $thing if $flags & $FL_ACTIVE;
	update_resonances($thing) if $flags & $FL_RESONATE;

	return $thing;
}

sub
breed() 
{
	my $MAX_CELLS = 8;
	my $MAX_SEEK_CELLS = 15;
	# use ceil for 1 to n, int for 0 to n-1

	# cap on free cells
	my $seeking_cells = 0;
	foreach my $cell (@{$tree{$CELL}}) {
		$seeking_cells++ if $$cell{state} & $SEEKING_GROUP;
	}
	return if $seeking_cells > $MAX_SEEK_CELLS;

	my $new_cells = int(rand() * $MAX_CELLS);
	# print "$new_cells new cells\n";
	foreach (1..$new_cells) {
		my $cell = create({
			type => $CELL,
			nature => $CELL,
			x => int(rand() * $GX),
			y => int(rand() * $GY),
			z => 0,
			state => $SEEK,
			life => $lifespan{$CELL},
			},
			$FL_ACTIVE | $FL_RESONATE);
		print "New cell $$cell{id} at $$cell{x}, $$cell{y}\n" if $debug;
	}
}

sub
add_new_wall($) 
{
	my $wall = shift;

	print "wall $$wall{id} created from $$wall{end_1} to $$wall{end_2} on $$wall{line}, horiz $$wall{horiz}\n" if $debug;
	# add the new thing to the system lists
	update_resonances($wall);

	# walls which are added to complete a room are never active and
	# the room's exclusion zone covers them.
	if ($$wall{state} == $BUILD) {
		$active_item{$$wall{id}} = $wall;
		# add the exclusions
		my $exclusion_rect = $$wall{horiz}
			? [ $$wall{end_1}-1,$$wall{line}-1, $$wall{end_2}+1, $$wall{line}+1 ]
			: [ $$wall{line}-1,$$wall{end_1}-1, $$wall{line}+1, $$wall{end_2}+1 ];
		$item_exclude{$$wall{id}} = [ $exclusion_rect ] ;
		prune_resonances($wall, $exclusion_rect);
	}

}

sub
build($$) 
{
	my ($existing_thing, $new_part) = @_;

	if ($$existing_thing{type} == $CELL) {
		if ($$new_part{type} != $CELL) {
			print "Something other than a cell ($$new_part{type}) is building onto a cell\n";
			return;
		}
		# ok, two cells are joining; a wall, corner, column, door,...?
		my $type = $WALL;
		# find out which cell is the top or left one
		my ($first_cell, $second_cell, $len, $horiz);
		if ($$existing_thing{x} == $$new_part{x}) {
			# vertical wall
			$first_cell = $$existing_thing{y} < $$new_part{y} ? $existing_thing : $new_part;
			$second_cell = $$existing_thing{y} < $$new_part{y} ? $new_part : $existing_thing;
			$len = $$second_cell{y} - $$first_cell{y} + 1;
			$horiz = 0;
		}
		else {
			# horiz wall
			$first_cell = $$existing_thing{x} < $$new_part{x} ? $existing_thing : $new_part;
			$second_cell = $$existing_thing{x} < $$new_part{x} ? $new_part : $existing_thing;
			$len = $$second_cell{x} - $$first_cell{x} + 1;
			$horiz = 1;
		}

		# create the new thing
		my $new_thing = create({
			type => $type,
			state => $BUILD,
			life => $lifespan{$type},
			end_1 => $horiz ? $$first_cell{x} : $$first_cell{y},
			end_2 => $horiz ? $$second_cell{x} : $$second_cell{y},
			line => $horiz ? $$first_cell{y} : $$first_cell{x},
			cells => [ $first_cell, $second_cell ],
			len => $len,
			horiz => $horiz,
			height => 0,
			base => 0,
			},0);

		# shut down the cells
		foreach my $cell ($existing_thing, $new_part) {
			$$cell{state} = $BUILD;
			# don't try to move these cells
			delete $active_item{$$cell{id}};
			# take the resonances for these cells off the list
			delete $item_res{$$cell{id}};
			$$cell{nature} = $WALL;
			$$cell{horiz} = $horiz;
			$$cell{object} = $new_thing;
		}

		add_new_wall($new_thing);

	}
	elsif ($$existing_thing{type} & $WALL_GROUP) {
		if ($$new_part{type} == $CELL) {
			# adjust wall; change the relevant end and add the cell to the wall's list
			if ($$existing_thing{horiz}) {
				if ($$new_part{x} == $$existing_thing{end_1}-1) {
					# new end 1
					$$existing_thing{end_1}--;
				}
				elsif ($$new_part{x} == $$existing_thing{end_2}+1) {
					# new end 2
					$$existing_thing{end_2}++;
				}
				else {
					print "Cell is joining a vertical wall/roof but not at an end\n";
					return;
				}
			}
			else {
				if ($$new_part{y} == $$existing_thing{end_1}-1) {
					# new end 1
					$$existing_thing{end_1}--;
				}
				elsif ($$new_part{y} == $$existing_thing{end_2}+1) {
					# new end 2
					$$existing_thing{end_2}++;
				}
				else {
					print "Cell is joining a vertical wall/roof but not at an end\n";
				}
			}
			# adjust other wall data
			push @{$$existing_thing{cells}}, $new_part;
			$$existing_thing{len}++;

			# adjust cell state & remove from lists
			$$new_part{state} = $$existing_thing{state};
			$$new_part{nature} = $$existing_thing{type};
			$$new_part{horiz} = $$existing_thing{horiz};
			$$new_part{angle} = $$existing_thing{angle} if $$existing_thing{type} == $ROOF;
			$$new_part{tile_shape} = $$existing_thing{tile_shape} if $$existing_thing{type} == $ROOF;
			$$new_part{z} = $$existing_thing{base} + $$existing_thing{height};
			$$new_part{object} = $existing_thing;
			delete $active_item{$$new_part{id}};
			delete $item_res{$$new_part{id}};

			# check if the wall was completed by this cell
			if ($$existing_thing{state} == $COMPLETING
				&& $$existing_thing{len} == $$existing_thing{final_end_2} - $$existing_thing{final_end_1} + 1)
			{
				print "Completed a line for wall/roof $$existing_thing{id}, state $$existing_thing{state}",
					", height $$existing_thing{height}, final height $$existing_thing{final_height}\n" if $debug;
				$$existing_thing{height}++;
				if ($$existing_thing{height} == $$existing_thing{final_height}) {
					# change the state of the wall to WAITING, ie for the rest of
					# the room. Do the same for the cells in the wall.
					$$existing_thing{state} = $WAITING;
					foreach my $cell (@{$$existing_thing{cells}}) {
						$$cell{state} = $$existing_thing{state};
					}
					delete $item_res{$$existing_thing{id}};
				}
				else {
					if ($$existing_thing{type} == $PEDIMENT) {
						$$existing_thing{final_end_1}++;
						$$existing_thing{final_end_2}--;
					}
					# just finished a row, build the next one
					# new resonances are in middle of wall
					$$existing_thing{end_1} = $$existing_thing{final_end_1}
						+ int(($$existing_thing{final_end_2}-$$existing_thing{final_end_1})/2) + 1;
					$$existing_thing{end_2} = $$existing_thing{final_end_1}
						+ int(($$existing_thing{final_end_2}-$$existing_thing{final_end_1})/2);
					$$existing_thing{len} = 0;
				}
			}
			elsif ($$existing_thing{state} == $BUILD) {
				# update the exclusions; the room exclusions take care of COMPLETING
				# walls.
				delete $item_exclude{$$existing_thing{id}};
				my $exclusion_rect = $$existing_thing{horiz}
						? [ $$existing_thing{end_1}-1,$$existing_thing{line}-1, 
							$$existing_thing{end_2}+1, $$existing_thing{line}+1 ]
						: [ $$existing_thing{line}-1,$$existing_thing{end_1}-1, 
							$$existing_thing{line}+1, $$existing_thing{end_2}+1 ];
				$item_exclude{$$existing_thing{id}} = [ $exclusion_rect ];
				prune_resonances($existing_thing, $exclusion_rect);
			}

			update_resonances($existing_thing) unless $$existing_thing{state} == $WAITING;
		}
		elsif ($$new_part{type} == $WALL) {
			# two parallel walls are building together to make a room.
			# the current extents of the pair define the final size.
			my $room_rect = [];
			if ($$new_part{horiz}) {
				$$room_rect[0] = min($$existing_thing{end_1}, $$new_part{end_1});
				$$room_rect[1] = min($$existing_thing{line}, $$new_part{line});
				$$room_rect[2] = max($$existing_thing{end_2}, $$new_part{end_2});
				$$room_rect[3] = max($$existing_thing{line}, $$new_part{line});
			}
			else {
				$$room_rect[0] = min($$existing_thing{line}, $$new_part{line});
				$$room_rect[1] = min($$existing_thing{end_1}, $$new_part{end_1});
				$$room_rect[2] = max($$existing_thing{line}, $$new_part{line});
				$$room_rect[3] = max($$existing_thing{end_2}, $$new_part{end_2});
			}

			# check that the proposed room doesn't impinge on any existing exclusion zones
			foreach my $id (keys %item_exclude) {
				# ignore exclusions for the two walls
				next if $id == $$existing_thing{id} || $id == $$new_part{id};
				foreach my $excl_rect (@{$item_exclude{$id}}) {
					return if rectangles_intersect($room_rect, $excl_rect);
				}
			}

			# wall height
			my $height = int((($$room_rect[2] - $$room_rect[0])+($$room_rect[3]-$$room_rect[1])/2)
				* ((3 + rand() * 4)/10));

			# create the new room
			my $new_thing = create({
				type => $ROOM,
				state => $BUILD,
				rect => $room_rect,
				height => $height,
				life => int($lifespan{$ROOM} * (200 /
					(($$room_rect[2] - $$room_rect[0])*($$room_rect[3]-$$room_rect[1]) * $height))),
				},$FL_ACTIVE);

			print "New room $$new_thing{id} from walls $$existing_thing{id} and $$new_part{id} , rect = @$room_rect, life = $$new_thing{life}\n" if $debug;

			# create the new walls for the room
			my @new_walls = ();
			foreach my $i (0..1) {
				my ($x, $y, $resmap);
				if ($$new_part{horiz}) {
					my $final_end_1 = $$room_rect[1] + 1;
					my $final_end_2 = $$room_rect[3] - 1;
					$x = $$room_rect[0 + 2 * $i];
					$y = $final_end_1 + int (($final_end_2 - $final_end_1 + 1)/2);
					$resmap = [ map [ 0, $_ - $y ], ($final_end_1 .. $final_end_2) ];
				}
				else {
					my $final_end_1 = $$room_rect[0] + 1;
					my $final_end_2 = $$room_rect[2] - 1;
					$x = $final_end_1 + int (($final_end_2 - $final_end_1 + 1)/2);
					$y = $$room_rect[1 + 2 * $i];
					$resmap = [ map [ $_ - $x, 0 ], ($final_end_1 .. $final_end_2) ];
				}

				my $new_wall = create({
					type => $MAP_WALL,
					state => $COMPLETING,
					x => $x,
					y => $y,
					resmap => $resmap,
					life => $lifespan{$WALL},
					room => $new_thing,
					cells => [],
					base => 0,
					final_height => $height,
					},0);

				print "New map wall $$new_wall{id} at $x,$y, horiz ! $$new_part{horiz}\n" if $debug;
				if ($debug) {
					foreach my $list_ref (@$resmap) {
						my ($x,$y) = @$list_ref;
						print "\t$x,$y\n";
					} 
				}

				push @new_walls, $new_wall;
			}

			# add the walls list to the room; they refer to each other, so we have
			# to do one creation first & then update the ref.
			$$new_thing{walls} = [ $existing_thing, $new_part, @new_walls ];

			# don't do this until the room knows about all its walls, otherwise
			# the walls inhibit each other's resonances.
			update_resonances($new_walls[0]);
			update_resonances($new_walls[1]);

			# do actions common to both existing walls
			foreach my $wall ($existing_thing, $new_part) {

				$$wall{room} = $new_thing;
				$$wall{final_end_1} = $$wall{horiz} ? $$room_rect[0] : $$room_rect[1];
				$$wall{final_end_2} = $$wall{horiz} ? $$room_rect[2] : $$room_rect[3];
				$$wall{final_height} = $height;
				$$wall{state} = $COMPLETING;

				# has the wall finished its first row already?
				if (($$wall{end_1} == $$wall{final_end_1} && $$wall{end_2} == $$wall{final_end_2})) {
					$$wall{height} = 1;
					if ($$wall{height} == $$wall{final_height}) {
						print "wall $$wall{id} waiting straight away\n" if $debug;
						$$wall{state} = $WAITING;
						delete $item_res{$$wall{id}};
					}
					else {
						# new resonances are in middle of wall
						$$wall{end_1} = $$wall{final_end_1} + int(($$wall{final_end_2}-$$wall{final_end_1})/2) + 1;
						$$wall{end_2} = $$wall{final_end_1} + int(($$wall{final_end_2}-$$wall{final_end_1})/2);
						$$wall{len} = 0;
					}
				}
				else {
					$$wall{height} = 0;
				}

				# set the cells to the wall's state
				foreach my $cell (@{$$wall{cells}}) {
					$$cell{state} = $$wall{state};
				}

				update_resonances($wall) unless $$wall{state} == $WAITING;
				# remove the walls from the active list (they aren't looking for 
				# other walls any more).
				delete $active_item{$$wall{id}};
				# remove the exclusions, since the room exclusions will handle the area.
				delete $item_exclude{$$wall{id}};
			}

			my $exclusion_rect = [ $$room_rect[0]-2, $$room_rect[1]-2, $$room_rect[2]+2, $$room_rect[3]+2];
			$item_exclude{$$new_thing{id}} = [ $exclusion_rect ];
			prune_resonances($new_thing, $exclusion_rect);
		}
		else {
			print "Thing $$new_part{id} with unexpected type ($$new_part{type}) is building onto wall or roof $$existing_thing{id}\n";
			return;
		}
	}
	elsif ($$existing_thing{type} & $MAP_GROUP) {
		if ($$new_part{type} == $CELL) {
			# find the index in the resmap of the resonance this cell has joined;
			# the offset from the cell position to the object origin will be the same as
			# the resmap entry.

=for comment
			my $cell_offset_x = $$new_part{x} - $$existing_thing{x};
			my $cell_offset_y = $$new_part{y} - $$existing_thing{y};
			my $index = 0;
			foreach my $res (@{$$existing_thing{resmap}}) {
				my ($x,$y) = @$res;
				last if $x == $cell_offset_x && $y == $cell_offset_y;
				$index++;
			}
=cut

			# when the cell joins the resonance, the resonance index is added to the cell
			my $index = $$new_part{res_index};
			if (!defined($index) || $index > $#{$$existing_thing{resmap}}) {
				print "Couldn't find matching res for cell\n";
				return;
			}

			print "Cell $$new_part{id} joining map object $$existing_thing{id} at res $index\n" if $debug;

			# adjust cell state & remove from lists
			$$new_part{state} = $$existing_thing{state};
			$$new_part{nature} = $$existing_thing{type};
			$$new_part{z} = $$existing_thing{base} + ${$$existing_thing{heights}}[$index];
			$$new_part{object} = $existing_thing;
			delete $active_item{$$new_part{id}};
			delete $item_res{$$new_part{id}};

			# adjust other column/wall data
			push @{$$existing_thing{cells}}, $new_part;
			${$$existing_thing{heights}}[$index]++;

			# check if the stack was completed by this cell
			if (${$$existing_thing{heights}}[$index] == $$existing_thing{final_height}) {
				print "Completed a stack for column/wall $$existing_thing{id}, state $$existing_thing{state}",
					", height ${$$existing_thing{heights}}[$index], final height $$existing_thing{final_height}\n" if $debug;

				# check if all the stacks in the thing are now done
				my $short_stack = 0;
				foreach my $stack_height (@{$$existing_thing{heights}}) {
					$short_stack = $stack_height < $$existing_thing{final_height};
					last if $short_stack;
				}

				if (! $short_stack) {
					# change the state of the thing to WAITING, ie for the rest of
					# the building/room. Do the same for the cells.
					$$existing_thing{state} = $WAITING;
					foreach my $cell (@{$$existing_thing{cells}}) {
						$$cell{state} = $$existing_thing{state};
					}
					delete $item_res{$$existing_thing{id}};
				}
				else {
					# we finished one stack so take off its resonance
					update_resonances($existing_thing);
				}
			}

		} # cell joining map thing
		else {
			print "Unknown thing joining map object: $$new_part{id}\n";
		}
	} # something joining map thing
	elsif ($$existing_thing{type} & $RESKEY_GROUP) {
		if ($$new_part{type} == $CELL) {

			# find the current resmap for the object; either by a function or a hash lookup
			my $resmap = $$existing_thing{resfunc}
				?  &{$$existing_thing{resfunc}}($existing_thing)
				: ${$$existing_thing{reskey}}{$$existing_thing{layer}};

			# when the cell joins the resonance, the resonance index is added to the cell
			my $index = $$new_part{res_index};
			if (!defined($index) || $index > $#$resmap) {
				print "Couldn't find matching res for cell\n";
				return;
			}
			my $attribs = ${$$resmap[$index]}[2];

			print "Cell $$new_part{id} joining map key object $$existing_thing{id} at res $index\n" if $debug;

			# adjust cell state & remove from lists
			$$new_part{state} = $$existing_thing{state};
			$$new_part{nature} = $$existing_thing{type};
			$$new_part{z} = $$existing_thing{base} + $$existing_thing{layer};
			$$new_part{object} = $existing_thing;
			foreach my $attrib (%$attribs) {
				$$new_part{$attrib} = $$attribs{$attrib};
			}
			delete $active_item{$$new_part{id}};
			delete $item_res{$$new_part{id}};

			# adjust other column/wall data
			push @{$$existing_thing{cells}}, $new_part;
			${$$existing_thing{filled_res}}[$index] = 1;

			# check if the layer was completed by this cell
			for ($index=0; $index <= $#$resmap; $index++) {
				last unless ${$$existing_thing{filled_res}}[$index];
			}
			if ($index > $#$resmap) {
				print "Completed layer $$existing_thing{layer} for reskey object $$existing_thing{id}",
					", state $$existing_thing{state}, final height $$existing_thing{final_height}\n" if $debug;
				$$existing_thing{layer}++;

				# check if this was the final layer
				if ($$existing_thing{layer} == $$existing_thing{final_height}) {
					# change the state of the thing to WAITING, ie for the rest of
					# the building/room. Do the same for the cells.
					$$existing_thing{state} = $WAITING;
					foreach my $cell (@{$$existing_thing{cells}}) {
						$$cell{state} = $$existing_thing{state};
					}
					delete $item_res{$$existing_thing{id}};
				}
				else {
					# clear filled resonance list
					$$existing_thing{filled_res} = [];
				}
			}

			# we have to update the resonances for every cell joining a layer
			update_resonances($existing_thing) unless $$existing_thing{state} == $WAITING;

		} # cell joining reskey thing
		else {
			print "Unknown thing joining reskey object: $$new_part{id}\n";
		}
	} # something joining reskey thing
	else {
		print "Unknown thing in build: $$existing_thing{id}\n";
	}

}

sub
find_best_spot($) 
{
	my $active_cell = shift;
	my $best_res = undef;
	my $best_score = 0;

	# all types of objects have a number of resonant locations,
	# each of which may have a different priority. For example,
	# extending an incomplete wall may have a higher priority than
	# starting a parallel wall. 

	# We find the "best" spot to move to based on range and
	# priority; we take priority/range to find each spot's score.
	print "Res scores for cell $$active_cell{id}:" if $debug;
	foreach my $resonant_item_id (keys %item_res) {
		print " id $resonant_item_id => (" if $debug;
		my $res_list_ref = $item_res{$resonant_item_id};
		foreach my $res (@$res_list_ref) {
			next unless $res;
			next if $active_cell == $$res{thing};
			my $score = get_res_score($active_cell, $res);
			print " $score" if $debug;
			if ($score > $best_score) {
				print "*" if $debug;
				$best_score = $score;
				$best_res = $res;
			}
		}
		print ")" if $debug;
	}

	if ($best_score) {

		print "Best resonance for $$active_cell{id} is at $$best_res{x}, $$best_res{y}\n" if $debug;
		# adjust the cell's position towards the resonance if necessary
		$$active_cell{x}++ if $$active_cell{x} < $$best_res{x};
		$$active_cell{x}-- if $$active_cell{x} > $$best_res{x};
		$$active_cell{y}++ if $$active_cell{y} < $$best_res{y};
		$$active_cell{y}-- if $$active_cell{y} > $$best_res{y};

		# did we get to the resonance?
		if ($$active_cell{x} == $$best_res{x} && $$active_cell{y} == $$best_res{y}) {
			# if this resonance has an index, set it in the cell
			$$active_cell{res_index} = $$best_res{res_index} if defined($$best_res{res_index});
			# the active cell should now be joined to whatever owned
			# the resonance
			build($$best_res{thing}, $active_cell);
		}
		else {
			print "cell $$active_cell{id} moved to $$active_cell{x},$$active_cell{y}\n" if $debug;
			update_resonances($active_cell) if $$active_cell{state} == $SEEK;
		}
	}
	else {
		print "No resonance for $$active_cell{id}\n" if $debug;
	}

}

# recursive use requires prototype
sub dissolve($$);
sub
dissolve($$)
{
	my ($thing, $cell_state) = @_;

	# we may get called on the same thing twice
	return if $$thing{state} == $DEAD;

	$$thing{state} = $DEAD;

	# don't care if these exist or not
	delete $active_item{$$thing{id}};
	delete $item_res{$$thing{id}};
	delete $item_exclude{$$thing{id}};

	if ($$thing{cells}) {
		foreach my $cell (@{$$thing{cells}}) {
			$$cell{state} = $cell_state;
			$active_item{$$cell{id}} = $cell if $cell_state == $JOIN;
		}
		$$thing{cells} = [];
	}
	elsif ($$thing{type} == $ROOM) {
		foreach my $component (@{$$thing{walls}},@{$$thing{roofs}},@{$$thing{pediments}}) {
			dissolve($component,$cell_state);
		}
	}
	else {
		print "Unexpected thing in dissolve: $$thing{id}\n";
	}
}

# recursive use requires prototype
sub ncr(@);
sub ncr(@)
{
	my $nbr_in_comb = shift;
	my @values = @_;
	my @combos = ();

	# the routine is failsafe (returns empty list) for values of N greater than the listsize;
	# make it safe for low values also.
	return ( [] ) if $nbr_in_comb <= 0;

	foreach my $val_indx (0 .. $#values - ($nbr_in_comb - 1)) {
		my $val = shift @values;
		if ($nbr_in_comb == 1) {
			push @combos, [ $val ];
		}
		else {
			foreach my $combo_ref (ncr($nbr_in_comb-1,@values)) {
				unshift @$combo_ref, $val;
				push @combos, $combo_ref;
			}
		}
	}

	return @combos;
}

sub
search() 
{

	my $thing;
	THING: foreach my $id (sort numeric keys %active_item) {
		# check the thing we get is still active; it may have joined with a
		# previous thing in this search.
		my $thing = $active_item{$id} or next;
		print "Found a dead thing in active list\n" if $$thing{state} == $DEAD;

		if ($$thing{type} == $CELL) {

			if ($$thing{life}-- == 0) {
				$$thing{state} = $DEAD;
				delete $active_item{$id};
				delete $item_res{$id};
				next THING;
			}

			find_best_spot($thing);
		}
		elsif ($$thing{type} == $WALL) {

			if ($$thing{life}-- == 0) {
				print "Wall $$thing{id} has died\n" if $debug;
				# this wall has run out of time to find a pair; kill it and all
				# its cells.
				dissolve($thing,$DEAD);
				# we have to update the resonances for everything else, since
				# they may have been inhibited by the exclusions of this wall.
				# Don't need to do anything higher than walls (rooms, roofs, map_walls, etc)
				# since they can't have overlapping exclusions.
				foreach my $cell (@{$tree{$CELL}}) {
					update_resonances($cell) if $$cell{state} == $SEEK;
				}
				foreach my $wall (@{$tree{$WALL}}) {
					update_resonances($wall) if $$wall{state} & ($BUILD | $COMPLETING);
				}
				next THING;
			}

			my $WALL_REACH = 1.5;
			my $MIN_WALL_SEP = 4;
			foreach my $other_wall (@{$tree{$WALL}}) {

				# checks before we see how close it is

				# not the same wall and not part of something already
				next if $thing == $other_wall || $$other_wall{state} != $BUILD;
				# same direction
				next unless $$thing{horiz} == $$other_wall{horiz};
				# not too close together
				next if abs($$thing{line} - $$other_wall{line}) < $MIN_WALL_SEP;

				my $distance = get_distance($thing, $other_wall);
				if ($distance < $$thing{len} * $WALL_REACH) {
					build($thing, $other_wall);
					next THING;
				}
			}

		}
		elsif ($$thing{type} == $ROOM) {

			if ($$thing{state} == $BUILD) {
				# check if initial walls are finished
				foreach my $wall (@{$$thing{walls}}) {
					next THING if $$wall{state} != $WAITING;
				}
				# all walls are waiting, so the room is finished.
				print "Room $$thing{id} has walls, roofing\n" if $debug;
				$$thing{state} = $COMPLETING;

				# the roof ridge runs along the longer side of the room
				my $rect = $$thing{rect};
				my ($horiz, $final_end_1, $final_end_2, $line, $span);
				if ($$rect[2] - $$rect[0] > $$rect[3] - $$rect[1]) {
					$horiz = 1;
					$line = $$rect[1];
					$span = $$rect[3] - $$rect[1] + 1;
					$final_end_1 = $$rect[0];
					$final_end_2 = $$rect[2];
				}
				else {
					$horiz = 0;
					$line = $$rect[0];
					$span = $$rect[2] - $$rect[0] + 1;
					$final_end_1 = $$rect[1];
					$final_end_2 = $$rect[3];
				}
				# create the roof sides and pediments
				$$thing{roofs} = [];
				$$thing{pediments} = [];
				for (0..1) {

					my $new_thing = create({
						type => $ROOF,
						state => $COMPLETING,
						horiz => $horiz,
						tile_shape => 1,
						angle => $horiz ? $_ ? 2 : 0 : $_ ? 1 : 3,
						end_1 => $final_end_1 + int(($final_end_2-$final_end_1)/2) + 1,
						end_2 => $final_end_1 + int(($final_end_2-$final_end_1)/2),
						line => $line + $_ * ($span - 1),
						final_end_1 => $final_end_1,
						final_end_2 => $final_end_2,
						room => $thing,
						cells => [],
						len => 0,
						height => 0,
						base => $$thing{height},
						final_height => int($span/2),
						},$FL_RESONATE);
					print "New roof $$new_thing{id}, line $$new_thing{line}, fe1 $final_end_1,",
						" fe2 $final_end_2, h $$new_thing{final_height}, span $span\n" if $debug;
					push @{$$thing{roofs}}, $new_thing;

					my $ped_fe_1 = $line + 1;
					my $ped_fe_2 = $line + $span - 2;
					$new_thing = create({
						type => $PEDIMENT,
						state => $COMPLETING,
						horiz => $horiz ? 0 : 1,
						line => $_ ? $final_end_2 : $final_end_1,
						final_end_1 => $ped_fe_1,
						final_end_2 => $ped_fe_2,
						room => $thing,
						cells => [],
						len => 0,
						height => 0,
						base => $$thing{height},
						final_height => int(($span-1)/2),
						}, $FL_RESONATE);
					print "New pediment $$new_thing{id} created\n" if $debug;
					push @{$$thing{pediments}}, $new_thing;

				}

				if ($span % 2) {
					# add a ridge line
					my $new_thing = create({
						type => $ROOF,
						state => $COMPLETING,
						horiz => $horiz,
						tile_shape => 2,
						line => $line + int($span/2),
						final_end_1 => $final_end_1,
						final_end_2 => $final_end_2,
						room => $thing,
						cells => [],
						len => 0,
						height => 0,
						base => $$thing{height} + int($span/2),
						final_height => 1,
					},$FL_RESONATE);
					push @{$$thing{roofs}}, $new_thing;
				}
			}
			elsif ($$thing{state} == $COMPLETING) {
				# check if roofs are finished
				foreach my $roof (@{$$thing{roofs}}) {
					next THING if $$roof{state} != $WAITING;
				}
				print "Room $$thing{id} completed\n" if $debug;
				$$thing{state} = $FINISHED;
			}
			elsif ($$thing{state} == $FINISHED) {

				if ($$thing{life}-- == 0) {
					print "Room $$thing{id} has died\n" if $debug;
					# this wall has run out of time to find a pair; kill it and free all
					# its cells.
					dissolve($thing,$JOIN);
					# we have to update the resonances for everything else, since
					# they may have been inhibited by the exclusions of this wall.
					# Don't need to do anything higher than walls (rooms, roofs,etc)
					# since they can't have overlapping exclusions.
					foreach my $cell (@{$tree{$CELL}}) {
						update_resonances($cell) if $$cell{state} == $SEEK;
					}
					foreach my $wall (@{$tree{$WALL}}) {
						update_resonances($wall) if $$wall{state} & ($BUILD | $COMPLETING);
					}
					next THING;
				}

				my $ROOM_REACH = 35;
				my $TARGET = 2500;
				my $ROOM_VALUE = 200;
				my $rect = $$thing{rect};
				my $score = $$thing{height} * ($$rect[2] - $$rect[0]) * ($$rect[3] - $$rect[1]);
				my @joining_list = ($thing);
				print "$$thing{id} is checking for other rooms, score = $score\n" if $debug;
				foreach my $other_room (@{$tree{$ROOM}}) {

					# checks before we see how close it is

					# not the same thing, ready for join
					next if $thing == $other_room || $$other_room{state} != $FINISHED;

					my $distance = get_distance($thing, $other_room);
					next if $distance > $ROOM_REACH;
					print "\tSees finished room $$other_room{id}\n" if $debug;
					push @joining_list, $other_room;
					my $other_rect = $$other_room{rect};
					$score += $ROOM_VALUE + $$other_room{height} 
						* ($$other_rect[2] - $$other_rect[0]) 
						* ($$other_rect[3] - $$other_rect[1]);
					print "\tNew score is $score\n" if $debug;
				}
				print "Final score is $score\n" if $debug;

				# we have to see if we can make the target while taking existing buildings into account
				my $best_score;

				if ($score >= $TARGET && $#joining_list > 1) {
					# we have a list of finished rooms to join together. We also want to
					# find all incomplete rooms and walls which impinge on the rectangle
					# encompassing the finished rooms. All these things will be knocked down
					# to free their cells for the building.

					# first check to see if this joining list differs from the previous one
					# for this building, which must have failed.
					if ($prev_joining_list{$$thing{id}}
						&& $#{$prev_joining_list{$$thing{id}}} == $#joining_list)
					{
						my @new_joining_list = @joining_list;
						my $change = 0;
						foreach my $thing (@{$prev_joining_list{$$thing{id}}}) {
							my $new_thing = shift @new_joining_list;
							$change = 1 && last if $new_thing != $thing;
						}
						if (! $change) {
							print "Joining list for $$thing{id} hasn't changed; don't bother\n" if $debug;
							next THING;
						}
					}
					$prev_joining_list{$$thing{id}} = [ @joining_list ];
					my $debug=1;

					# we must ensure this building rectangle doesn't impinge on the exclusion
					# zone for other buildings. If it does, we prune the joining list until
					# it doesn't any more (but still makes the target)

					# the -2 in the next line means we will have at least three things in the
					# joining list after any skips.
					my @building_rect;
					foreach my $nbr_skips (0..min($#joining_list-2,2)) {

						$best_score = undef;
						my $best_skip_index = undef;

						# @skips contains a list of lists of thing refs, ie a list of skip lists
						my @skips = ncr($nbr_skips, @joining_list);

						print "nbr_skips = $nbr_skips, $#skips skip lists\n" if $debug;
						my $skip_index = 0;
						SKIPLIST: foreach my $skip_combo_ref (@skips) {
							if ($debug) {
								print "skip list:\n";
								foreach my $thing (@$skip_combo_ref) {
									print " $$thing{id}";
								}
								print "\n";
							}

							# find the bounds of the finished buildings;
							@building_rect = ($GX,$GY,-1,-1);
							my $score = 0;
							ROOM: foreach my $room (@joining_list) {

								# skip any rooms in the skip list
								foreach my $thing (@$skip_combo_ref) {
									print "Skipping $$room{id}\n" if $room == $thing && $debug;
									next ROOM if $room == $thing;
								}

								print "Bounds for room $$room{id} = @{$$room{rect}}\n" if $debug;
								foreach (0..1) {
									$building_rect[$_] = min($building_rect[$_], ${$$room{rect}}[$_]);
								}
								foreach (2..3) {
									$building_rect[$_] = max($building_rect[$_], ${$$room{rect}}[$_]);
								}
								my $rect = $$room{rect};
								$score += $ROOM_VALUE + $$room{height} 
									* ($$rect[2] - $$rect[0]) * ($$rect[3] - $$rect[1]);
							}
							print "Building rect = @building_rect\n" if $debug;

							# have we still made the target after skips
							if ($score < $TARGET) {
								print "Target not made after skips\n" if $debug;
								next; # next skip list
							}

							$best_score = 0 unless defined($best_score);

							# check that the new building doesn't conflict with any existing
							# buildings; this can happen if the candidate rooms are clustered
							# around one of the corners of the existing building.
							foreach my $building (@{$tree{$BUILDING}}) {
								if (rectangles_intersect(\@building_rect, $$building{rect})) {
									print "Clash with existing building $$building{id}\n" if $debug;
									next SKIPLIST;
								}
							}

							# valid skip list (makes target, doesn't clash with other buildings) so record it
							if ($score > $best_score) {
								print "New best score; old = $best_score, new = $score, i = $skip_index\n" if $debug;
								$best_score = $score;
								$best_skip_index = $skip_index;
							}
						} 
						continue {
							$skip_index++;
						} # SKIPLIST

						if (! defined($best_score)) {
							# we never even got to check building intersections, ie the
							# target was never made. Skipping more rooms won't help so bail.
							print "Target never reached, skip room\n" if $debug;
							last;
						}

						# did we find a combination that reached the score without clashing?
						if ($best_score > 0) {
							# yep.
							print "Found valid joining list; score = $best_score, skip# = $best_skip_index\n" if $debug;
							# we only need to care about skips if we actually have some;
							# otherwise, the existing joining_list is fine.
							if ($nbr_skips > 0) {
								# ok, build a new joining list (much easier than pruning old one)
								my $skip_list = $skips[$best_skip_index];
								my @new_joining_list = ();
								ROOM: foreach my $room (@joining_list) {
									# skip any rooms in the skip list
									foreach my $thing (@$skip_list) {
										print "New J list; skipping $$room{id}\n" if $room == $thing && $debug;
										next ROOM if $room == $thing;
									}
									# add the room to the new list
									push @new_joining_list, $room;
								}
								@joining_list = @new_joining_list;
							}

							# recalc the building rect with the final J list
							@building_rect = ($GX,$GY,-1,-1);
							foreach my $room (@joining_list) {
								foreach (0..1) {
									$building_rect[$_] = min($building_rect[$_], ${$$room{rect}}[$_]);
								}
								foreach (2..3) {
									$building_rect[$_] = max($building_rect[$_], ${$$room{rect}}[$_]);
								}
							}

							# bail out of the skip loop; the minimum number of skips is what we want.
							last;
						}

					} # number of skips loop

					# did we find a valid list?
					if (!defined($best_score) || $best_score == 0) {
						# nope; bail on this room
						print "No valid list found after existing building check\n" if $debug;
						next;
					}

					# find the rooms/walls in that area; we may be adding rooms twice
					# but dissolve is smart enough to ignore dead things.
					foreach my $other_thing (@{$tree{$ROOM}}, @{$tree{$WALL}}) {
						# walls in non-build state will be included by their rooms
						next if $$other_thing{type} == $WALL && $$other_thing{state} != $BUILD;
						my $other_rect = $$other_thing{type} == $WALL
							? $$other_thing{horiz}
								? [ $$other_thing{end_1}, $$other_thing{line}, 
									$$other_thing{end_2}, $$other_thing{line} ] 
								: [ $$other_thing{line}, $$other_thing{end_1}, 
									$$other_thing{line}, $$other_thing{end_2} ] 
							: $$other_thing{rect};
						push @joining_list, $other_thing if rectangles_intersect(\@building_rect, $other_rect);
					}
					print "Final joining list", map (" $$_{id}", @joining_list), "\n" if $debug;

					# make a plan!
					my ($point, $width, $height) = make_plan;
					if ($debug) {
						print "plan of $width x $height\n";
						foreach (@$point) { my ($x,$y) = @$_; print "\t$x,$y\n"; }
					}

					my @grid_sizes = (10,8,6,4,2,0);
					my $grid_size;
					foreach (@grid_sizes) {
						$grid_size = $_;
						# bail out if the smallest grid didn't fit.
						last if $grid_size == 0;
						# fit the plan to our area and convert the unit points to real locations
						print "Checking grid size $grid_size\n" if $debug;
						last if fit_plan($point, $width, $height, $grid_size, @building_rect);
					}

					if ($grid_size == 0) {
						print "Couldn't fit plan to area\n" if $debug;
						next;
					}

					if ($debug) {
						foreach (@$point) { my ($x,$y) = @$_; print "\t$x,$y\n"; }
					}

					# dissolve all the joining things; remove resonances,
					# exclusions, active items, and set all cells to join (ie seek without
					# resonating), and set the component states to DEAD.
					foreach (@joining_list) {
						dissolve($_,$JOIN);
					}

					# update all floating wall & cell resonances in case they were inhibited by something
					# we just killed. Anything in a room can't have inhibited resonances.
					foreach my $other_thing (@{$tree{$WALL}}, @{$tree{$CELL}}) {
						next if $$other_thing{type} == $WALL && $$other_thing{state} != $BUILD;
						next if $$other_thing{type} == $CELL && $$other_thing{state} != $SEEK;
						update_resonances($other_thing);
					}

					# create the building
					my $building = create({
						type => $BUILDING,
						state => $BUILD,
						rect => \@building_rect,
						columns => [],
						size => $grid_size,
						height => $grid_size * 2 + 2,
						}, $FL_ACTIVE);
					$item_exclude{$$building{id}} = [ \@building_rect ];
					prune_resonances($building, \@building_rect);

					# map the grid size to a column size
					my %column_size = (
						10 => 3,
						8 => 3,
						6 => 3,
						4 => 2,
						2 => 1,
						);
					# maps for each column size
					my %column_res_map = (
						1 => [ [0,0] ],
						2 => [ [1,0], [0,1], [-1,0], [0,-1] ],
						3 => [ [-1,-1], [0,-1], [1,-1], [1,0], 
								[1,1], [0,1], [-1,1], [-1,0] ],
						);

					# create a pillar for each offset
					foreach (@$point) {
						my ($x,$y) = @$_;
						my $column = create({
							type => $COLUMN,
							size => $column_size{$grid_size},
							state => $COMPLETING,
							x => $x,
							y => $y,
							building => $building,
							cells => [],
							resmap => $column_res_map{$column_size{$grid_size}},
							final_height => $$building{height},
							base => 0,
						},$FL_RESONATE);
						push @{$$building{columns}}, $column;
					}

				} # creating a building
			} # room finished
		} # room
		elsif ($$thing{type} == $BUILDING) {
		}
		else {
			print "Unknown type of thing (id $id, $$thing{type}) in active item\n";
		}
	}
}

sub
report() 
{
	print "\n", "*" x 80, "\nReport; gen $gen, $next_id items created\n";
	print "Cell count: ", scalar(@{$tree{$CELL}}), "\n";
	print "Wall count: ", scalar(@{$tree{$WALL}}), " -> ";
	foreach my $wall (@{$tree{$WALL}}) { print " $$wall{id}"; } print "\n";
	print "Room count: ", scalar(@{$tree{$ROOM}}), " -> ";
	foreach my $room (@{$tree{$ROOM}}) { print " $$room{id}"; } print "\n";
	if ($tree{$ROOF}) {
		print "Roof count: ", scalar(@{$tree{$ROOF}}), " -> ";
		foreach my $roof (@{$tree{$ROOF}}) { print " $$roof{id}"; } print "\n";
	}

	my %type_total;
	print "Resonant items: ", scalar keys %item_res, " -> ";
	foreach my $id (sort numeric keys %item_res) {
		print " $id";
		my $thing = undef;
		THING: foreach (sort numeric keys %tree) {
			foreach my $tree_thing (@{$tree{$_}}) {
				if ($id == $$tree_thing{id}) {
					$thing = $tree_thing;
					last THING;
				}
			}
		}
		$type_total{$$thing{type}}++ if ($thing);
	}
	print "\n";
	foreach (sort numeric keys %type_total) {
		print "\t$_ = $type_total{$_}\n";
	}

	print "Active items: ", scalar keys %active_item, " -> ";
	%type_total = ();
	foreach my $id (sort numeric keys %active_item) {
		print " $id";
		my $thing = undef;
		THING: foreach (sort numeric keys %tree) {
			foreach my $tree_thing (@{$tree{$_}}) {
				if ($id == $$tree_thing{id}) {
					$thing = $tree_thing;
					last THING;
				}
			}
		}
		$type_total{$$thing{type}}++ if ($thing);
	}
	print "\n";
	foreach (sort numeric keys %type_total) {
		print "\t$_ = $type_total{$_}\n";
	}

	print "Excluding items: ", scalar keys %item_exclude, " -> ";
	foreach (sort numeric keys %item_exclude) { print " $_"; } print "\n";
	print "*" x 80, "\n\n";
	render_tk_3d(1);
}

sub 
inspect_selection($) 
{
	my $entry = shift;

	if ($entry->selectionPresent()) {
		my $start = $entry->index('sel.first');
		my $end = $entry->index('sel.last');
		my $sel_text = substr($entry->get(), $start, $end-$start+1);
		my @ids = $sel_text =~ /(\d+)/g;
		foreach (@ids) {
			inspect($_);
		}
	}

}
sub
inspect($) 
{
	my $id = shift;
	my $thing = undef;
	my @lines;

	# we don't have a master list of items, so find it in the tree
	THING: foreach (sort numeric keys %tree) {
		foreach my $tree_thing (@{$tree{$_}}) {
			if ($id == $$tree_thing{id}) {
				$thing = $tree_thing;
				last THING;
			}
		}
	}
	if ($thing) {
		foreach (sort keys %$thing) {
			if (/(walls|cells|pediments|roofs|columns)/) {
				my $line = "$_ = [";
				foreach my $child (@{$$thing{$_}}) {
					$line .= " $$child{id}";
				}
				$line .= " ]";
				push @lines, $line;
			}
			elsif (/(room|building|object)/) {
				push @lines, "$_ = ${$$thing{$_}}{id}";
			}
			elsif (/rect|heights/) {
				my $line = "$_ = (";
				foreach my $val (@{$$thing{$_}}) {
					$line .= " $val";
				}
				$line .= " )";
				push @lines, $line;
			}
			elsif (/resmap/) {
				my $line = "$_ = [";
				foreach my $res (@{$$thing{$_}}) {
					$line .= " ($$res[0],$$res[1])";
				}
				$line .= " ]";
				push @lines, $line;
			}
			else {
				push @lines, "$_ = $$thing{$_}";
			}
		}
	}
	else {
		push @lines, "No thing found with id $id";
	}

	if (0) {
		print "+" x 80, "\n";
		print "Inspecting $id; gen $gen, $next_id items created\n";
		foreach (@lines) {
			print "$_\n";
		}
		print "+" x 80, "\n\n";
	}
	else {
		my $inspect_win;
		my $inspect_text;
		if (! Exists($inspect_win)) {
			$inspect_win = $main_win->Toplevel();
			$inspect_win->transient($main_win);
			$inspect_win->title("Inspect $id");
			# $inspect_win->Button( -text => "Close", -command => sub { $inspect_win->withdraw })->pack;
			$inspect_text = $inspect_win->Scrolled("ROText", -scrollbars => 'oe',
				-width => 37, -wrap => 'none')->pack(-expand => 1, -fill => 'both');
		}
		else {
			$inspect_win->deiconify();
			$inspect_win->raise();
		}
		my $nbr_buttons = 0;
		my $window_height = $#lines * 22 + 30;
		while ($_ = shift @lines) {
			my ($b,$e);
			# do we look like a label=value pair?
			if (my ($label,$val) = /([^\s]+) = (.+)/) {
				# parse label/value pair

				# create the entry first so the button (if any) can reference it
				if ($val =~ /\[(.*)\]/) {
					$val = $1;
				}
				$e = $inspect_text->Entry();
				$e->insert('end', "$val");
				$e->configure(-state => 'disabled');

				# create a label or button
				if ($label =~ /(cells|roofs|pediments|walls|columns|room|building|object)/) {
					$nbr_buttons++;
					$b = $inspect_text->Button(-text => "$label",  -relief => 'groove', -width => 12, -height => 1,
						-command => [ \&inspect_selection, $e ] )
				}
				else {
					$b = $inspect_text->Label(-text => "$label",  -relief => 'groove', -width => 15);
				}

				# add label/button, then entry
				$inspect_text->windowCreate('end', -window => $b);
				$inspect_text->windowCreate('end', -window => $e);
			}
			else {
				$inspect_text->insert('end', "$_");
			}
			$inspect_text->insert('end', "\n") if $#lines > -1;
		}
		$window_height += 6 * $nbr_buttons;
		$inspect_win->geometry("265x$window_height");
	}
}

sub
init_tk() 
{

	my @colors = qw(red orange yellow green blue violet);

	$main_win = MainWindow->new;
	$red_img = $main_win->Photo(-file=>'redblock.png');
	$green_img = $main_win->Photo(-file=>'greenblock.png');
	$blue_img = $main_win->Photo(-file=>'blueblock.png');
	foreach (@colors) {
		$small_img{$_} = $main_win->Photo(-file => "${_}6x6.png");
		$td_img{$_} = $main_win->Photo(-file => "${_}3d3.png");
	}
	foreach (qw(n s e w nw ne se sw point)) {
		$td_img{"blue_roof_$_"} = $main_win->Photo(-file => "blue_roof_$_.png");
	}
	foreach (qw(ns ew)) {
		$td_img{"blue_ridge_$_"} = $main_win->Photo(-file => "blue_ridge_$_.png");
	}
	$roof_img{w} = $main_win->Photo(-file => "yellow_roof_w.png");
	$roof_img{s} = $main_win->Photo(-file => "yellow_roof_s.png");

	$main_win->Button(-text => 'Pause', -command => sub { $stop_flag = !$stop_flag; render_tk_3d(1) if $stop_flag; })->grid(
		$main_win->Button(-text => 'Step', -command => sub { $stop_flag = 2; }),
		$main_win->Button(-text => 'Debug', -command => sub { $debug = !$debug; }),
		$main_win->Button(-text => 'Report', -command => sub { report; }),
		$main_win->Button(-text => 'Inspect', -command => sub { inspect($id_to_inspect); }),
		$main_win->Entry(-textvariable => \$id_to_inspect, -width => 10),
		$main_win->Button(-text => 'Quit', -command => sub { print "Byebye\n"; exit; }),
		-sticky => 'ew');

	$main_win->Button(-text => 'Refresh 2D', -command => sub { render_tk; })->grid(
		$main_win->Button(-text => 'Refresh 3D', -command => sub { render_tk_3d(1); }),
		$main_win->Button(-text => 'Spin', -command => sub { $spin = ($spin + 1) % 4; render_tk_3d(1); }),
		# $main_win->Entry(-textvariable => \$spin, -width => 10),
		$main_win->Button(-text => 'Refresh?', -command => sub { $refresh = !$refresh; }),
		-sticky => 'ew');

	$main_win->Label(-textvariable => \$gen, -width => 10)->grid(
		$main_win->Label(-text => 'Stop After'),
		$main_win->Entry(-textvariable => \$stop_after_gen, -width => 10),
		$main_win->Label(-text => 'Debug After'),
		$main_win->Entry(-textvariable => \$debug_after_gen, -width => 10),
		-sticky => 'ew');

	$td_canvas = $main_win->Canvas(
		-background => 'grey',
		-width => 6 * $GX + 6 * $GY + 30,
		-height => 3 * $GX + 3 * $GY + 100,
		);
	$td_canvas->grid("-","-","-","-","-","-");
	$td_canvas->CanvasBind("<Button-1>", [ \&tracker, Ev('x'), Ev('y') ] );

=for comment
	$td_win = $main_win->Toplevel();
	$td_canvas = $td_win->Canvas(
		-background => 'grey',
		-width => 6 * $GX + 6 * $GY + 30,
		-height => 3 * $GX + 3 * $GY + 100,
		);
	$td_canvas->pack(-side => 'left');
	$td_win->title('3d view');
	$td_win->geometry("+400+10");
=cut

}

sub
main_loop() 
{

	# pause or step button
	#$main_win->waitVariable(\$stop_flag) if $stop_flag == 1;

	my $report_count = 1000;

	$gen++;

	print "\nGen $gen\n---------\n" if $debug;

	my $start_time = Time::HiRes::time() if $gen % $report_count == 0;

	breed unless $gen % $breed_speed;
	search;

	# delete the dead things
	foreach my $type ($CELL,$WALL,$ROOM,$ROOF,$PEDIMENT) {
		for (my $i=$#{$tree{$type}}; $i >= 0; $i--) {
			my $thing = ${$tree{$type}}[$i];
			splice @{$tree{$type}},$i,1 if $$thing{state} == $DEAD;
		}
	}

	render_tk_3d($stop_flag == 2) if $refresh || $stop_flag == 2;

	# pause at a problem
	$stop_flag = 1 if $gen == $stop_after_gen;
	$debug = 1 if $gen == $debug_after_gen;

	unless ($gen % $report_count) {
		my $end_time = Time::HiRes::time();
		print "\nLoop time = ", $end_time - $start_time;
		report;
	}

	# if we've stepped thru 1 gen, pause
	$stop_flag = 1 if $stop_flag == 2;

}

sub main() 
{
	$SIG{INT} = sub { done("Ouch!") };
	init_tk;

	open (LOG_FH, ">>$logfile") or die "Couldn't open $logfile: $!";
	# save stdout
	$stdout_fh = select(LOG_FH);
	# we want unbuffered writing to the log
	$| = 1;
	print "$0 started at ", scalar localtime, "\n";
	print "\$X = $GX, \$Y = $GY\n";

	srand 2;

=for comment

		reskey => {
			0 => [
				[ -1, -1, { angle => 0, nature => $ROOF, tile_shape => 3 } ],
				[ 2, -1, { angle => 1, nature => $ROOF, tile_shape => 3 } ],
				[ 2, 2, { angle => 2, nature => $ROOF, tile_shape => 3 } ],
				[ -1, 2, { angle => 3, nature => $ROOF, tile_shape => 3 } ],
				[ 0, -1, { nature => $ROOF, tile_shape => 1, angle => 0 } ],
				[ 1, -1, { nature => $ROOF, tile_shape => 1, angle => 0 } ],
				[ 2, 0, { nature => $ROOF, tile_shape => 1, angle => 1 } ],
				[ 2, 1, { nature => $ROOF, tile_shape => 1, angle => 1 } ],
				[ 0, 2, { nature => $ROOF, tile_shape => 1, angle => 2 } ],
				[ 1, 2, { nature => $ROOF, tile_shape => 1, angle => 2 } ],
				[ -1, 0, { nature => $ROOF, tile_shape => 1, angle => 3 } ],
				[ -1, 1, { nature => $ROOF, tile_shape => 1, angle => 3 } ],
				],
			1 => [
				[ 0, 0, { angle => 0, nature => $ROOF, tile_shape => 3 } ],
				[ 1, 0, { angle => 1, nature => $ROOF, tile_shape => 3 } ],
				[ 1, 1, { angle => 2, nature => $ROOF, tile_shape => 3 } ],
				[ 0, 1, { angle => 3, nature => $ROOF, tile_shape => 3 } ],
				],
			},
=cut

	# test object
	create({
		type => $RESKEY_THING,
		state => $COMPLETING,
		x => 10,
		y => 10,
		x_dim => 3,
		y_dim => 3,
		resfunc => \&pyramid_res_map,
		base => 0,
		},$FL_RESONATE) unless 0;

	while (1) {
		main_loop;
		$main_win->update;
		$main_win->waitVariable(\$stop_flag) if $stop_flag == 1;
	}
}

main;

